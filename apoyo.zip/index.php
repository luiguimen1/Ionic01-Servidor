<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="css/miCSS.css">
        <script src="js/jquery-1.10.2.min.js" type="text/javascript"></script>
        <script src="js/jquery.validate.js" type="text/javascript"></script>
        <script src="js/additional-methods.js" type="text/javascript"></script>
        <script src="js/localization/messages_es.js" type="text/javascript"></script>
        <script src="js/MiLibreria.js" type="text/javascript"></script>
    </head>
    <body>
        <div id="pagina">
            <div id="enca"></div>
            <div id="cuerpo">
                <div id="menu">
                    <h2>El menu</h2>
                    <ul>
                        <li id="uno">uno</li>
                        <li id="lunes">Formulario</li>
                        <li id="martes">Listar</li>
                        <li id="miercoles">Sin desarrollo</li>
                    </ul>
                </div>
                <div id="contenido">
                <center> <h1>Esta es la pagina  de desarrollo movil</h1></center>
                    
                <center> <h2>Por lUis Alvarez</h2></center>                
                </div>
            </div>
            <div id="pie"></div>
        </div>
    </body>
</html>